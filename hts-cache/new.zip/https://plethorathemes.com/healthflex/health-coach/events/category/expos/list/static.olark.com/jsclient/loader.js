<!doctype html>
<html class="no-js" lang="en-US">
<head>
<meta charset="UTF-8">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="HandheldFriendly" content="true">
<meta name="apple-touch-fullscreen" content="yes">
<title>Upcoming Events &#8211; Health Coach</title>
<link rel='dns-prefetch' href='//s0.wp.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Health Coach &raquo; Feed" href="https://plethorathemes.com/healthflex/health-coach/feed/" />
<link rel="alternate" type="application/rss+xml" title="Health Coach &raquo; Comments Feed" href="https://plethorathemes.com/healthflex/health-coach/comments/feed/" />
<link rel="alternate" type="text/calendar" title="Health Coach &raquo; iCal Feed" href="https://plethorathemes.com/healthflex/health-coach/events/?ical=1" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.4\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.4\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/plethorathemes.com\/healthflex\/health-coach\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.5"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55357,56692,8205,9792,65039],[55357,56692,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='tribe-events-bootstrap-datepicker-css-css'  href='https://plethorathemes.com/healthflex/health-coach/wp-content/plugins/the-events-calendar/vendor/bootstrap-datepicker/css/bootstrap-datepicker.standalone.min.css?ver=4.9.5' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='https://plethorathemes.com/healthflex/health-coach/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.0.1' type='text/css' media='all' />
<link rel='stylesheet' id='tribe-events-custom-jquery-styles-css'  href='https://plethorathemes.com/healthflex/health-coach/wp-content/plugins/the-events-calendar/vendor/jquery/smoothness/jquery-ui-1.8.23.custom.css?ver=4.9.5' type='text/css' media='all' />
<link rel='stylesheet' id='tribe-accessibility-css-css'  href='https://plethorathemes.com/healthflex/health-coach/wp-content/plugins/the-events-calendar/common/src/resources/css/accessibility.min.css?ver=4.7.10' type='text/css' media='all' />
<link rel='stylesheet' id='tribe-events-full-calendar-style-css'  href='https://plethorathemes.com/healthflex/health-coach/wp-content/plugins/the-events-calendar/src/resources/css/tribe-events-full.min.css?ver=4.6.13' type='text/css' media='all' />
<link rel='stylesheet' id='tribe-events-calendar-style-css'  href='https://plethorathemes.com/healthflex/health-coach/wp-content/plugins/the-events-calendar/src/resources/css/tribe-events-theme.min.css?ver=4.6.13' type='text/css' media='all' />
<link rel='stylesheet' id='tribe-events-calendar-full-mobile-style-css'  href='https://plethorathemes.com/healthflex/health-coach/wp-content/plugins/the-events-calendar/src/resources/css/tribe-events-full-mobile.min.css?ver=4.6.13' type='text/css' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' id='tribe-events-calendar-mobile-style-css'  href='https://plethorathemes.com/healthflex/health-coach/wp-content/plugins/the-events-calendar/src/resources/css/tribe-events-theme-mobile.min.css?ver=4.6.13' type='text/css' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' id='jetpack-widget-social-icons-styles-css'  href='https://plethorathemes.com/healthflex/health-coach/wp-content/plugins/jetpack/modules/widgets/social-icons/social-icons.css?ver=20170506' type='text/css' media='all' />
<link rel='stylesheet' id='plethora-icons-css'  href='https://plethorathemes.com/healthflex/health-coach/wp-content/uploads/sites/3/plethora/plethora_icons.css?uniqeid=57f6b15aa176a&#038;ver=4.9.5' type='text/css' media='all' />
<link rel='stylesheet' id='animate-css'  href='https://plethorathemes.com/healthflex/health-coach/wp-content/themes/healthflex/includes/core/assets/css/libs/animate/animate.min.css?ver=4.9.5' type='text/css' media='all' />
<link rel='stylesheet' id='plethora-custom-bootstrap-css'  href='https://plethorathemes.com/healthflex/health-coach/wp-content/themes/healthflex/assets/css/theme_custom_bootstrap.css?ver=4.9.5' type='text/css' media='all' />
<link rel='stylesheet' id='plethora-dynamic-style-css'  href='https://plethorathemes.com/healthflex/health-coach/wp-content/uploads/wp-less/healthflex/assets/less/style-5444320e80.css' type='text/css' media='all' />
<link rel='stylesheet' id='plethora-style-css'  href='https://plethorathemes.com/healthflex/health-coach/wp-content/themes/healthflex-child/style.css?ver=4.9.5' type='text/css' media='all' />
<link rel='stylesheet' id='redux-google-fonts-plethora_options-css'  href='https://fonts.googleapis.com/css?family=Varela+Round%3A400%7CMontserrat%3A100%2C200%2C300%2C400%2C500%2C600%2C700%2C800%2C900%2C100italic%2C200italic%2C300italic%2C400italic%2C500italic%2C600italic%2C700italic%2C800italic%2C900italic&#038;subset=latin&#038;ver=4.9.5' type='text/css' media='all' />
<link rel='stylesheet' id='jetpack_css-css'  href='https://plethorathemes.com/healthflex/health-coach/wp-content/plugins/jetpack/css/jetpack.css?ver=6.0' type='text/css' media='all' />
<script type='text/javascript' src='https://plethorathemes.com/healthflex/health-coach/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='https://plethorathemes.com/healthflex/health-coach/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='https://plethorathemes.com/healthflex/health-coach/wp-content/plugins/the-events-calendar/vendor/jquery-placeholder/jquery.placeholder.min.js?ver=2.0.7'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var tribe_bootstrap_datepicker_strings = {"dates":{"days":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"daysShort":{"Jan":"Jan","Feb":"Feb","Mar":"Mar","Apr":"Apr","May":"May","Jun":"Jun","Jul":"Jul","Aug":"Aug","Sep":"Sep","Oct":"Oct","Nov":"Nov","Dec":"Dec"},"daysMin":["S","M","T","W","T","F","S"],"months":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthsShort":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"clear":"Clear","today":"Today","titleFormat":"MM yyyy"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://plethorathemes.com/healthflex/health-coach/wp-content/plugins/the-events-calendar/vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js?ver=3.2'></script>
<script type='text/javascript' src='https://plethorathemes.com/healthflex/health-coach/wp-content/plugins/the-events-calendar/vendor/jquery-resize/jquery.ba-resize.min.js?ver=1.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var tribe_js_config = {"permalink_settings":"\/%year%\/%monthnum%\/%day%\/%postname%\/","events_post_type":"tribe_events","events_base":"https:\/\/plethorathemes.com\/healthflex\/health-coach\/events\/"};
/* ]]> */
</script>
<script type='text/javascript' src='https://plethorathemes.com/healthflex/health-coach/wp-content/plugins/the-events-calendar/src/resources/js/tribe-events.min.js?ver=4.6.13'></script>
<script type='text/javascript' src='https://plethorathemes.com/healthflex/health-coach/wp-content/plugins/the-events-calendar/src/resources/js/tribe-events-bar.min.js?ver=4.6.13'></script>
<script type='text/javascript' src='https://plethorathemes.com/healthflex/health-coach/wp-content/themes/healthflex/includes/core/assets/js/libs/modernizr/modernizr.custom.48287.js?ver=4.9.5'></script>
<link rel='https://api.w.org/' href='https://plethorathemes.com/healthflex/health-coach/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://plethorathemes.com/healthflex/health-coach/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://plethorathemes.com/healthflex/health-coach/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.9.5" />
<meta name="tec-api-version" content="v1"><meta name="tec-api-origin" content="https://plethorathemes.com/healthflex/health-coach"><link rel="https://theeventscalendar.com/" href="https://plethorathemes.com/healthflex/health-coach/wp-json/tribe/events/v1/events/?categories=loader.js" />
<link rel='dns-prefetch' href='//v0.wordpress.com'/>
<link rel='dns-prefetch' href='//i0.wp.com'/>
<link rel='dns-prefetch' href='//i1.wp.com'/>
<link rel='dns-prefetch' href='//i2.wp.com'/>
<meta name="generator" content="Powered by Visual Composer - drag and drop page builder for WordPress."/>
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="https://plethorathemes.com/healthflex/health-coach/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]--> <meta name="robots" content="noindex,follow" />
<noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>			<!-- USER DEFINED IN-LINE CSS -->
			<style>
				@media (min-width: 1460px) { .container {width: 1380px;} }
.head_panel .hgroup .title h1, article.post .post_title, .widget h4,
.section_header.fancy h1, .section_header.fancy h2, .section_header.fancy h3, .section_header.fancy h4, .section_header.fancy h5, .section_header.fancy h6 { font-weight: inherit; }
.btn {border-radius: 30px;}
.btn.with-icon i {border-radius:  0 30px 30px 0;width: auto;padding: 0 10px;}
.btn.with-icon.icon-left i {border-radius: 30px 0 0 30px;padding: 0 8px 0 13px;}
.teaser_box .with_button a.btn {border-radius: 3px 3px 0 0 ;}
.widget h4 {  text-transform: none; }
.wpcf7-form-control, .wpcf7-form-control.wpcf7-date, .form-control {  border-radius: 18px;  margin-bottom: 16px;}div.datepicker { z-index: 19 !important; }			</style></head>
<body class="error404 tribe-no-js tribe-filter-live wpb-js-composer js-comp-ver-5.2.1 vc_responsive events-list events-archive tribe-events-style-full tribe-events-style-theme tribe-theme-parent-healthflex tribe-theme-child-healthflex-child tribe-events-page-template sticky_header ">
	<div class="overflow_wrapper">
		<div class="header ">  <div class="mainbar  color">
    <div class="container">
               <div class="logo">
            <a href="https://plethorathemes.com/healthflex/health-coach" class="brand">
                          <img src="https://i1.wp.com/plethorathemes.com/healthflex/health-coach/wp-content/uploads/sites/3/2016/02/healthcoach_logo_color.png?fit=529%2C100&#038;ssl=1" alt="HealthFlex">
                        </a>
                      </div>                   <div class="menu_container"><span class="close_menu">&times;</span>
                <ul id="menu-one-pager-menu" class="main_menu hover_menu"><li id="menu-item-140" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-140"><a title="Home" href="https://plethorathemes.com/healthflex/health-coach/">Home</a></li>
<li id="menu-item-139" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-139"><a title="About" href="https://plethorathemes.com/healthflex/health-coach/about/">About</a></li>
<li id="menu-item-138" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-138"><a title="Work with me" href="https://plethorathemes.com/healthflex/health-coach/work-with-me/">Work with me</a></li>
<li id="menu-item-137" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-137"><a title="Success stories" href="https://plethorathemes.com/healthflex/health-coach/success-stories/">Success stories</a></li>
<li id="menu-item-136" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-136"><a title="Blog" href="https://plethorathemes.com/healthflex/health-coach/blog/">Blog</a></li>
<li id="menu-item-135" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-135"><a title="Connect" href="https://plethorathemes.com/healthflex/health-coach/connect/">Connect</a></li>
<li id="menu-item-141" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-141 lihasdropdown"><a title="More" href="#">More  </a>
<ul role="menu" class=" menu-dropdown">
	<li id="menu-item-132" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-132"><a title="Single Service Page" href="https://plethorathemes.com/healthflex/health-coach/individual-session-service/">Single Service Page</a></li>
	<li id="menu-item-133" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-133"><a title="FAQ" href="https://plethorathemes.com/healthflex/health-coach/frequently-asked-questions/">FAQ</a></li>
	<li id="menu-item-299" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-299"><a title="Recipes" href="https://plethorathemes.com/healthflex/health-coach/category/recipes/">Recipes</a></li>
	<li id="menu-item-543" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-543"><a title="Events Calendar" href="/healthflex/health-coach/events/">Events Calendar</a></li>
	<li id="menu-item-492" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-492"><a title="Buy this Theme!" target="_blank" href="http://themeforest.net/item/healthflex-medical-health-wordpress-theme/13115123">Buy this Theme!</a></li>
</ul>
</li>
<li id="menu-item-142" class="btn btn-sm btn-secondary menu-item menu-item-type-custom menu-item-object-custom menu-item-142"><a title="Other Demos!" href="http://plethorathemes.com/healthflex/all-demos">Other Demos!</a></li>
</ul>        </div>

        <label class="mobile_collapser">MENU</label> <!-- Mobile menu title -->
    </div>
  </div>

		</div>

	<div class="head_panel">
    <div style="background-image: url(http://plethorathemes.com/healthflex/health-coach/wp-content/themes/healthflex/assets/images/404_alt.jpg)" class="full_width_photo   ">


      <div class="hgroup">

        <div class="title diagonal-bgcolor-trans   ">
          <div class="container">
            <h1>OMG! ERROR 404</h1>
          </div>
        </div>

        <div class="subtitle body-bg_section   ">
          <div class="container">   
            <p>The requested page cannot be found!</p>
          </div>
        </div>

      </div>


    </div>
</div>      <div class="brand-colors"> </div>
    <div class="main" ><section class="vc_off sidebar_off " ><div class="container"><div class="row"><div class="col-md-12"><div id="tribe-events-pg-template" class="tribe-events-pg-template">
	<div id="tribe-events" class="tribe-no-js" data-live_ajax="1" data-datepicker_format="0" data-category="" data-featured=""><div class="tribe-events-before-html"></div><span class="tribe-events-ajax-loading"><img class="tribe-events-spinner-medium" src="https://plethorathemes.com/healthflex/health-coach/wp-content/plugins/the-events-calendar/src/resources/images/tribe-loading.gif" alt="Loading Events" /></span>	<div id="tribe-events-content-wrapper" class="tribe-clearfix"><input type="hidden" id="tribe-events-list-hash" value="">
	<!-- Tribe Bar -->


<div id="tribe-events-bar">

	<form id="tribe-bar-form" class="tribe-clearfix" name="tribe-bar-form" method="post" action="https://plethorathemes.com/healthflex/health-coach/events/category/expos/list/static.olark.com/jsclient/loader.js?post_type=tribe_events&#038;tribe_events_cat=loader.js&#038;eventDisplay=default">

		<!-- Mobile Filters Toggle -->

		<div id="tribe-bar-collapse-toggle" >
			Find Events<span class="tribe-bar-toggle-arrow"></span>
		</div>

		<!-- Views -->
					<div id="tribe-bar-views">
				<div class="tribe-bar-views-inner tribe-clearfix">
					<h3 class="tribe-events-visuallyhidden">Event Views Navigation</h3>
					<label>View As</label>
					<select
						class="tribe-bar-views-select tribe-no-param tribe-accessible-js-hidden"
						name="tribe-bar-view"
						tabindex="0"
						aria-label="View As"
					>
													<option selected value="https://plethorathemes.com/healthflex/health-coach/events/list/" data-view="list">
								List							</option>
													<option tribe-inactive value="https://plethorathemes.com/healthflex/health-coach/events/month/" data-view="month">
								Month							</option>
											</select>
				</div>
				<!-- .tribe-bar-views-inner -->
			</div><!-- .tribe-bar-views -->
		
					<div class="tribe-bar-filters">
				<div class="tribe-bar-filters-inner tribe-clearfix">
											<div class="tribe-bar-date-filter">
							<label class="label-tribe-bar-date" for="tribe-bar-date">Events From</label>
							<input type="text" name="tribe-bar-date" style="position: relative;" id="tribe-bar-date" value="" placeholder="Date"><input type="hidden" name="tribe-bar-date-day" id="tribe-bar-date-day" class="tribe-no-param" value="">						</div>
											<div class="tribe-bar-search-filter">
							<label class="label-tribe-bar-search" for="tribe-bar-search">Search</label>
							<input type="text" name="tribe-bar-search" id="tribe-bar-search" value="" placeholder="Keyword">						</div>
										<div class="tribe-bar-submit">
						<input class="tribe-events-button tribe-no-param" type="submit" name="submit-bar" value="Find Events" />
					</div>
					<!-- .tribe-bar-submit -->
				</div>
				<!-- .tribe-bar-filters-inner -->
			</div><!-- .tribe-bar-filters -->
		
	</form>
	<!-- #tribe-bar-form -->

</div><!-- #tribe-events-bar -->

	<!-- Main Events Content -->

<div id="tribe-events-content" class="tribe-events-list">


	
	<!-- List Title -->
		<h2 class="tribe-events-page-title">Upcoming Events</h2>
	
	<!-- Notices -->
	<div class="tribe-events-notices"><ul><li>There were no results found.</li></ul></div>
	<!-- List Header -->
		<div id="tribe-events-header"  data-title="Upcoming Events &#8211; Health Coach" data-startofweek="1" data-view="list" data-baseurl="https://plethorathemes.com/healthflex/health-coach/events/list/">

		<!-- Header Navigation -->
				
<h3 class="screen-reader-text" tabindex="0">Events List Navigation</h3>
<ul class="tribe-events-sub-nav">
	<!-- Left Navigation -->

	
	<!-- Right Navigation -->
	</ul>
		
	</div>
	<!-- #tribe-events-header -->
	

	<!-- Events Loop -->
	
	<!-- List Footer -->
		<div id="tribe-events-footer">

		<!-- Footer Navigation -->
				
<h3 class="screen-reader-text" tabindex="0">Events List Navigation</h3>
<ul class="tribe-events-sub-nav">
	<!-- Left Navigation -->

	
	<!-- Right Navigation -->
	</ul>
		
	</div>
	<!-- #tribe-events-footer -->
	
</div><!-- #tribe-events-content -->

	<div class="tribe-clear"></div>

</div> <!-- #tribe-events-content-wrapper -->	<div class="tribe-events-after-html"></div></div><!-- #tribe-events --><p class="tribe-events-promo">Calendar powered by <a class="vcard url org fn" href="https://theeventscalendar.com/product/wordpress-events-calendar/?utm_medium=plugin-tec&utm_source=banner&utm_campaign=in-app">The Events Calendar</a></p>
<!--
This calendar is powered by The Events Calendar.
http://m.tri.be/18wn
-->
</div> <!-- #tribe-events-pg-template -->
</div></div></div></section></div>		<footer class="sep_angled_positive_top separator_top ">
		 				<div class="container">
                  	<div class="row">
                	<div class="col-sm-12 col-md-6"><!-- ========================== WIDGET ABOUT US ==========================-->

<aside id="plethora-aboutus-widget-2" class="widget aboutus-widget">

<div class="pl_about_us_widget  ">

		<p><img src="https://plethorathemes.com/healthflex/health-coach/wp-content/uploads/sites/3/2016/02/healthcoach_logo_white_retina_h50.png" alt=""  style="max-width:"></p>


		<p>Premium Wordpress Theme mainly Medical Oriented but so flexible that lets you build various layouts for any "Health & Beauty" related business!</p>


		<p class='contact_detail'><i class='fa fa-phone'></i><span>(+30) 210 1234567</span></p>



		<p class='contact_detail'><i class='fa fa-envelope'></i><span><a href='mailto:info@healthcoach.com'>info@healthcoach.com</a></span></p>



	
	<p class="contact_detail">
			<i class='fa fa-location-arrow'></i>
		<span>79 Folsom Ave, San Francisco, CA 94107</span>
	</p>


	<p class="social">

			<a href='#' target='_blank' title="Twitter"><i class='fa fa-twitter'></i></a>
			<a href='#' target='_blank' title="Facebook"><i class='fa fa-facebook'></i></a>
			<a href='#' target='_blank' title="Google+"><i class='fa fa-google-plus'></i></a>
			<a href='#' target='_blank' title="LinkedIn"><i class='fa fa-linkedin'></i></a>
			<a href='#' target='_blank' title="Instagram"><i class='fa fa-instagram'></i></a>
			<a href='#' target='_blank' title="Skype"><i class='fa fa-skype'></i></a>
			<a href='#' target='_blank' title="Send Us An Email"><i class='fa fa-envelope'></i></a>
	</p>

	
	
</div>

</aside>

<!-- END======================= WIDGET ABOUT US ==========================--></div>
<div class="col-sm-6 col-md-3"><aside id="nav_menu-2" class="widget widget_nav_menu"><h4>Quick Links</h4><div class="menu-footer-menu-container"><ul id="menu-footer-menu" class="menu"><li id="menu-item-490" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-490"><a href="https://plethorathemes.com/healthflex/health-coach/">Home</a></li>
<li id="menu-item-491" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-491"><a href="https://plethorathemes.com/healthflex/health-coach/success-stories/">Success stories</a></li>
<li id="menu-item-487" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-487"><a href="https://plethorathemes.com/healthflex/health-coach/work-with-me/">Work with me</a></li>
<li id="menu-item-485" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-485"><a href="https://plethorathemes.com/healthflex/health-coach/frequently-asked-questions/">Frequently asked questions</a></li>
<li id="menu-item-486" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-486"><a href="https://plethorathemes.com/healthflex/health-coach/connect/">Connect</a></li>
<li id="menu-item-489" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-489"><a href="#">More</a>
<ul class="sub-menu">
	<li id="menu-item-483" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-483"><a href="https://plethorathemes.com/healthflex/health-coach/pricing/">Pricing Plans</a></li>
	<li id="menu-item-484" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-484"><a href="https://plethorathemes.com/healthflex/health-coach/individual-session-service/">Individual Session (Service)</a></li>
</ul>
</li>
<li id="menu-item-488" class="btn btn-sm btn-secondary menu-item menu-item-type-custom menu-item-object-custom menu-item-488"><a href="https://plethorathemes.com/healthflex/all-demos">Other Demos!</a></li>
</ul></div></aside></div>
<div class="col-sm-6 col-md-3"><!-- ===================== LATEST NEWS: MUSTACHE ========================-->

 <aside id="plethora-latestnews-widget-2" class="widget latestnews-widget">

 <div class="pl_latest_news_widget">
 <h4>Latest Articles </h4>
 <ul class="media-list">

    <li class="media">

     <a href="https://plethorathemes.com/healthflex/health-coach/2016/03/01/how-to-deal-with-emotional-eating/" class="media-photo" style="background-image:url(' https://i2.wp.com/plethorathemes.com/healthflex/health-coach/wp-content/uploads/sites/3/2016/02/eating-donut.jpg?resize=150%2C150&#038;ssl=1 ')"></a> 

     <h5 class="media-heading">
      <a href="https://plethorathemes.com/healthflex/health-coach/2016/03/01/how-to-deal-with-emotional-eating/">How to deal with Emotional Eating</a>
      <small>Mar 1</small> 
     </h5>
     <p>Sed in felis velit. Quisque porta turpis vel leo accumsan...</p>
    </li>


    <li class="media">

     <a href="https://plethorathemes.com/healthflex/health-coach/2016/03/01/weight-loss-fitness/" class="media-photo" style="background-image:url(' https://i2.wp.com/plethorathemes.com/healthflex/health-coach/wp-content/uploads/sites/3/2016/02/success-story-person.jpg?resize=150%2C150&#038;ssl=1 ')"></a> 

     <h5 class="media-heading">
      <a href="https://plethorathemes.com/healthflex/health-coach/2016/03/01/weight-loss-fitness/">Lose Weight by coming to terms with the way you see yourself!</a>
      <small>Mar 1</small> 
     </h5>
     <p>It&#8217;s a familiar story: You pledge to honor a daily...</p>
    </li>


    <li class="media">

     <a href="https://plethorathemes.com/healthflex/health-coach/2016/03/01/mussels-marinara-di-amore/" class="media-photo" style="background-image:url(' https://i1.wp.com/plethorathemes.com/healthflex/health-coach/wp-content/uploads/sites/3/2016/03/Mussels-Marinara-di-Amore.jpg?resize=150%2C150&#038;ssl=1 ')"></a> 

     <h5 class="media-heading">
      <a href="https://plethorathemes.com/healthflex/health-coach/2016/03/01/mussels-marinara-di-amore/">Mussels Marinara di Amore</a>
      <small>Mar 1</small> 
     </h5>
     <p>INGREDIENTS For the Greek Vinaigrette 1 clove garlic 3 tablespoons...</p>
    </li>

 </ul>
 </div>  

 </aside>

 <!-- END================== LATEST NEWS: MUSTACHE ========================--></div>					</div>
				</div>		</footer>
		            <div class="copyright dark_section">
              <div class="dark_section transparent_film">
                 <div class="container">
                      <div class="row">
                           <div class="col-sm-6 col-md-6">
            					Copyright &copy;2016 all rights reserved                           </div>
                           <div class="col-sm-6 col-md-6 text-right">
            					Designed by <a href="http://plethorathemes.com" target="_blank">Plethora Themes</a>                           </div>
                      </div>
                 </div>
              </div>
            </div></div><a href="javascript:" id="return-to-top"><i class="fa fa-chevron-up"></i></a>		<script>
		( function ( body ) {
			'use strict';
			body.className = body.className.replace( /\btribe-no-js\b/, 'tribe-js' );
		} )( document.body );
		</script>
			<script type="text/javascript" async>

	/* GOOGLE ANALYTICS */
	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

	ga('create', 'UA-55444186-5', 'auto');
	ga('send', 'pageview');

	/* OLARK CODE */
	;(function(o,l,a,r,k,y){if(o.olark)return;
	r="script";y=l.createElement(r);r=l.getElementsByTagName(r)[0];
	y.async=1;y.src="//"+a;r.parentNode.insertBefore(y,r);
	y=o.olark=function(){k.s.push(arguments);k.t.push(+new Date)};
	y.extend=function(i,j){y("extend",i,j)};
	y.identify=function(i){y("identify",k.i=i)};
	y.configure=function(i,j){y("configure",i,j);k.c[i]=j};
	k=y._={s:[],t:[+new Date],c:{},l:a};
	})(window,document,"static.olark.com/jsclient/loader.js");

	/* Add configuration calls bellow this comment */

	olark.identify('5031-201-10-2467');

	/* HOTJAR CODE */
	(function(h,o,t,j,a,r){
	        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
	        h._hjSettings={hjid:84643,hjsv:5};
	        a=o.getElementsByTagName('head')[0];
	        r=o.createElement('script');r.async=1;
	        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
	        a.appendChild(r);
	})(window,document,'//static.hotjar.com/c/hotjar-','.js?sv=');

	</script>

<script> /* <![CDATA[ */var tribe_l10n_datatables = {"aria":{"sort_ascending":": activate to sort column ascending","sort_descending":": activate to sort column descending"},"length_menu":"Show _MENU_ entries","empty_table":"No data available in table","info":"Showing _START_ to _END_ of _TOTAL_ entries","info_empty":"Showing 0 to 0 of 0 entries","info_filtered":"(filtered from _MAX_ total entries)","zero_records":"No matching records found","search":"Search:","all_selected_text":"All items on this page were selected. ","select_all_link":"Select all pages","clear_selection":"Clear Selection.","pagination":{"all":"All","next":"Next","previous":"Previous"},"select":{"rows":{"0":"","_":": Selected %d rows","1":": Selected 1 row"}},"datepicker":{"dayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"dayNamesShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"dayNamesMin":["S","M","T","W","T","F","S"],"monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesShort":["January","February","March","April","May","June","July","August","September","October","November","December"],"nextText":"Next","prevText":"Prev","currentText":"Today","closeText":"Done"}};/* ]]> */ </script><script type='text/javascript'>
/* <![CDATA[ */
var TribeList = {"ajaxurl":"https:\/\/plethorathemes.com\/healthflex\/health-coach\/wp-admin\/admin-ajax.php","tribe_paged":"0"};
/* ]]> */
</script>
<script type='text/javascript' src='https://plethorathemes.com/healthflex/health-coach/wp-content/plugins/the-events-calendar/src/resources/js/tribe-events-ajax-list.min.js?ver=4.6.13'></script>
<script type='text/javascript' src='https://plethorathemes.com/healthflex/health-coach/wp-content/plugins/jetpack/_inc/build/photon/photon.min.js?ver=20130122'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"https:\/\/plethorathemes.com\/healthflex\/health-coach\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}},"cached":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://plethorathemes.com/healthflex/health-coach/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.0.1'></script>
<script type='text/javascript' src='https://s0.wp.com/wp-content/js/devicepx-jetpack.js?ver=201818'></script>
<script type='text/javascript' src='https://plethorathemes.com/healthflex/health-coach/wp-content/themes/healthflex/includes/core/assets/js/libs/totop/jquery.ui.totop.js?ver=4.9.5'></script>
<script type='text/javascript' src='https://plethorathemes.com/healthflex/health-coach/wp-content/themes/healthflex/assets/js/libs/bootstrap.min.js?ver=4.9.5'></script>
<script type='text/javascript' src='https://plethorathemes.com/healthflex/health-coach/wp-content/themes/healthflex/includes/core/assets/js/libs/easing/easing.min.js?ver=4.9.5'></script>
<script type='text/javascript' src='https://plethorathemes.com/healthflex/health-coach/wp-content/themes/healthflex/includes/core/assets/js/libs/wow/wow.min.js?ver=4.9.5'></script>
<script type='text/javascript' src='https://plethorathemes.com/healthflex/health-coach/wp-content/themes/healthflex/includes/core/assets/js/libs/conformity/dist/conformity.min.js?ver=4.9.5'></script>
<script type='text/javascript' src='https://plethorathemes.com/healthflex/health-coach/wp-content/themes/healthflex/assets/js/libs/particlesjs/particles.min.js?ver=4.9.5'></script>
<script type='text/javascript' src='https://plethorathemes.com/healthflex/health-coach/wp-content/themes/healthflex/includes/core/assets/js/libs/parallax/parallax.min.js?ver=4.9.5'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var themeConfig = {"GENERAL":{"debug":false},"NEWSLETTERS":{"messages":{"successMessage":"SUCCESS","errorMessage":"ERROR","required":"This field is required.","remote":"Please fix this field.","url":"Please enter a valid URL.","date":"Please enter a valid date.","dateISO":"Please enter a valid date ( ISO ).","number":"Please enter a valid number.","digits":"Please enter only digits.","creditcard":"Please enter a valid credit card number.","equalTo":"Please enter the same value again.","name":"Please specify your name","email":{"required":"We need your email address to contact you","email":"Your email address must be in the format of name@domain.com"}}},"PARTICLES":{"enable":true,"color":"#bcbcbc","opacity":0.8,"bgColor":"transparent","bgColorDark":"transparent","colorParallax":"#4D83C9","bgColorParallax":"transparent"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://plethorathemes.com/healthflex/health-coach/wp-content/themes/healthflex/assets/js/theme.js?ver=4.9.5'></script>
<script type='text/javascript' src='https://plethorathemes.com/healthflex/health-coach/wp-includes/js/wp-embed.min.js?ver=4.9.5'></script>
<!-- TEMPLATE PART: /plugins/the-events-calendar/src/views/default-template.php -->				<script type='text/javascript'>
					(function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:84643,hjsv:5};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'//static.hotjar.com/c/hotjar-','.js?sv=');				</script>
								<script type='text/javascript'>
					(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-55444186-5', 'auto');
  ga('send', 'pageview');				</script>
				</body>
</html>